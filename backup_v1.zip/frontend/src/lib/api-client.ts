import { api } from './api';
import type {
  LoginRequest,
  LoginResponse,
  User,
  Channel,
  ChannelMember,
  Feedback,
  FeedbackComment,
  FeedbackCreate,
  Notification,
  Announcement,
  AnnouncementCreate,
  FileUpload,
  SystemMetrics,
  UserMetrics,
  AuditLog,
} from './types';

// ===== Auth API =====
export const authApi = {
  login: async (data: LoginRequest): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/auth/login', data);
    return response.data;
  },

  logout: async (): Promise<void> => {
    await api.post('/auth/logout');
  },

  getCurrentUser: async (): Promise<User> => {
    const response = await api.get<User>('/auth/me');
    return response.data;
  },

  refreshToken: async (refreshToken: string): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/auth/refresh', {
      refresh_token: refreshToken,
    });
    return response.data;
  },
};

// ===== Users API =====
export const usersApi = {
  getAll: async (): Promise<{ users: User[]; total: number }> => {
    const response = await api.get('/users');
    return response.data;
  },

  getById: async (id: number): Promise<User> => {
    const response = await api.get<User>(`/users/${id}`);
    return response.data;
  },
};

// ===== Channels API =====
export const channelsApi = {
  getAll: async (): Promise<{ channels: Channel[]; total: number }> => {
    const response = await api.get('/channels');
    return response.data;
  },

  getById: async (id: number): Promise<Channel> => {
    const response = await api.get<Channel>(`/channels/${id}`);
    return response.data;
  },

  create: async (data: { name: string; description?: string; channel_type: string; is_private?: boolean }): Promise<Channel> => {
    const response = await api.post<Channel>('/channels', data);
    return response.data;
  },

  update: async (id: number, data: Partial<Channel>): Promise<Channel> => {
    const response = await api.patch<Channel>(`/channels/${id}`, data);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/channels/${id}`);
  },

  getMembers: async (id: number): Promise<{ members: ChannelMember[]; total: number }> => {
    const response = await api.get(`/channels/${id}/members`);
    return response.data;
  },
};

// ===== Memberships API =====
export const membershipsApi = {
  join: async (channelId: number): Promise<ChannelMember> => {
    const response = await api.post<ChannelMember>('/memberships/join', { channel_id: channelId });
    return response.data;
  },

  leave: async (channelId: number): Promise<void> => {
    await api.post('/memberships/leave', { channel_id: channelId });
  },

  getMyChannels: async (): Promise<{ channels: Channel[]; total: number }> => {
    const response = await api.get('/memberships/my-channels');
    return response.data;
  },
};

// ===== Feedback API =====
export const feedbackApi = {
  getAll: async (params?: { status?: string; category?: string }): Promise<{ feedback: Feedback[]; total: number }> => {
    const response = await api.get('/feedback', { params });
    return response.data;
  },

  getById: async (id: number): Promise<Feedback> => {
    const response = await api.get<Feedback>(`/feedback/${id}`);
    return response.data;
  },

  create: async (data: FeedbackCreate): Promise<Feedback> => {
    const response = await api.post<Feedback>('/feedback', data);
    return response.data;
  },

  update: async (id: number, data: Partial<Feedback>): Promise<Feedback> => {
    const response = await api.patch<Feedback>(`/feedback/${id}`, data);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/feedback/${id}`);
  },

  getComments: async (id: number): Promise<{ comments: FeedbackComment[]; total: number }> => {
    const response = await api.get(`/feedback/${id}/comments`);
    return response.data;
  },

  addComment: async (id: number, comment: string): Promise<FeedbackComment> => {
    const response = await api.post<FeedbackComment>(`/feedback/${id}/comments`, { comment });
    return response.data;
  },

  getStats: async (): Promise<any> => {
    const response = await api.get('/feedback/stats');
    return response.data;
  },
};

// ===== Notifications API =====
export const notificationsApi = {
  getAll: async (params?: { is_read?: boolean; type?: string }): Promise<{ notifications: Notification[]; total: number; unread_count: number }> => {
    const response = await api.get('/notifications', { params });
    return response.data;
  },

  markAsRead: async (id: number): Promise<Notification> => {
    const response = await api.patch<Notification>(`/notifications/${id}/read`);
    return response.data;
  },

  markAllAsRead: async (): Promise<{ marked: number }> => {
    const response = await api.post('/notifications/mark-all-read');
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/notifications/${id}`);
  },

  deleteAll: async (): Promise<{ deleted: number }> => {
    const response = await api.delete('/notifications/delete-all');
    return response.data;
  },
};

// ===== Announcements API =====
export const announcementsApi = {
  getAll: async (params?: { category?: string; is_pinned?: boolean }): Promise<{ announcements: Announcement[]; total: number; pinned_count: number }> => {
    const response = await api.get('/announcements', { params });
    return response.data;
  },

  getById: async (id: number): Promise<Announcement> => {
    const response = await api.get<Announcement>(`/announcements/${id}`);
    return response.data;
  },

  create: async (data: AnnouncementCreate): Promise<Announcement> => {
    const response = await api.post<Announcement>('/announcements', data);
    return response.data;
  },

  update: async (id: number, data: Partial<Announcement>): Promise<Announcement> => {
    const response = await api.patch<Announcement>(`/announcements/${id}`, data);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/announcements/${id}`);
  },

  getStats: async (): Promise<any> => {
    const response = await api.get('/announcements/stats');
    return response.data;
  },
};

// ===== Files API =====
export const filesApi = {
  upload: async (file: File, entityType?: string, entityId?: number): Promise<FileUpload> => {
    const formData = new FormData();
    formData.append('file', file);
    
    const params = new URLSearchParams();
    if (entityType) params.append('entity_type', entityType);
    if (entityId) params.append('entity_id', entityId.toString());
    
    const response = await api.post<FileUpload>(`/files?${params.toString()}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },

  download: async (id: number): Promise<Blob> => {
    const response = await api.get(`/files/${id}`, { responseType: 'blob' });
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/files/${id}`);
  },

  getMyFiles: async (): Promise<{ files: FileUpload[]; total: number }> => {
    const response = await api.get('/files/me');
    return response.data;
  },

  getEntityFiles: async (entityType: string, entityId: number): Promise<{ files: FileUpload[]; total: number }> => {
    const response = await api.get(`/files/entity/${entityType}/${entityId}`);
    return response.data;
  },
};

// ===== Admin API =====
export const adminApi = {
  getSystemMetrics: async (): Promise<SystemMetrics> => {
    const response = await api.get<SystemMetrics>('/admin/metrics/system');
    return response.data;
  },

  getUserMetrics: async (): Promise<UserMetrics[]> => {
    const response = await api.get<UserMetrics[]>('/admin/metrics/users');
    return response.data;
  },

  assignFeedback: async (feedbackId: number, assigneeId: number): Promise<any> => {
    const response = await api.post('/admin/feedback/assign', {
      feedback_id: feedbackId,
      assignee_id: assigneeId,
    });
    return response.data;
  },

  updateUserStatus: async (userId: number, isActive: boolean): Promise<User> => {
    const response = await api.patch<User>(`/admin/users/${userId}/status`, { is_active: isActive });
    return response.data;
  },

  updateUserRole: async (userId: number, role: string): Promise<User> => {
    const response = await api.patch<User>(`/admin/users/${userId}/role`, { role });
    return response.data;
  },

  getAuditLogs: async (params?: { page?: number; page_size?: number; user_id?: number; action?: string }): Promise<{ logs: AuditLog[]; total: number; page: number; page_size: number }> => {
    const response = await api.get('/admin/audit-logs', { params });
    return response.data;
  },
};
