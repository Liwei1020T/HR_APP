"""
Core modules initialization.
"""
