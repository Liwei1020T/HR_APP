"""Admin module for system administration."""
