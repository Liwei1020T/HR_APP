"""
Auth module initialization.
"""
