"""
Announcements module initialization.
"""
