"""Files module for handling file uploads and downloads."""
