"""
Feedback module initialization.
"""
