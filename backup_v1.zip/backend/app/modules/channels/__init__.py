"""
Channels module initialization.
"""
