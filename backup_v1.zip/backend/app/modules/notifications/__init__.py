"""
Notifications module initialization.
"""
