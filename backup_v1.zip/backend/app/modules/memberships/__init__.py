"""
Memberships module initialization.
"""
