"""
Application modules initialization.
"""
