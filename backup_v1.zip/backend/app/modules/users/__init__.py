"""
Users module initialization.
"""
